<?php
include("css.php");
?>

<!DOCTYPE html>
<html lang="en">

<body id="page-top">

    <div class="card shadow">
        <div class="card-header">
            Edit Data Tanggapan
        </div>
        <div class="card-body">

            <?php
            require '../koneksi.php';
            $sql = mysqli_query($koneksi, "SELECT * FROM tanggapan WHERE id_tanggapan='$_GET[id]'");
            if ($data = mysqli_fetch_array($sql)) { ?>

                <form action="update_tanggapan.php" method="POST" class="form-horizontal" enctype="multipart/form-data">
                    <div class="form-group cols-sm-6">
                        <label>ID Tanggapan</label>
                        <input type="text" name="id_tanggapan" value="<?php echo $data['id_tanggapan']; ?>"
                            class="form-control" readonly>
                    </div>
                    <div class="form-group cols-sm-6">
                        <label>ID Pengaduan</label>
                        <input type="text" name="id_pengaduan" value="<?php echo $data['id_pengaduan']; ?>"
                            class="form-control" readonly>
                    </div>
                    <div class="form-group cols-sm-6">
                        <label>Tanggal Tanggapan</label>
                        <input type="text" name="tgl_tanggapan" value="<?php echo $data['tgl_tanggapan']; ?>"
                            class="form-control" readonly>
                    </div>
                    <div class="form-group cols-sm-6">
                        <label>Tanggapan</label>
                        <input type="text" name="tanggapan" value="<?php echo $data['tanggapan']; ?>" class="form-control">
                    </div>
                    <div class="form-group cols-sm-6">
                        <label>ID Petugas</label>
                        <input type="text" name="id_petugas" value="<?php echo $data['id_petugas']; ?>" class="form-control"
                            readonly>
                    </div>

                    <div class="form-group col-sm-6"></div>
                    <input type="submit" value="Edit Data" class="btn btn-primary">
                    <input type="reset" value="Kosongkan" class="btn btn-warning">
            </div>

            </form>
        <?php } ?>

</body>

</html>