<?php
include("css.php");
?>

<!DOCTYPE html>
<html lang="en">

<body id="page-top">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Laporan</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID Pengaduan</th>
                            <th>Tanggal Pengaduan</th>
                            <th>Nik</th>
                            <th>Isi Laporan</th>
                            <th>Foto</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <?php
                    require '../koneksi.php';
                    $sql = mysqli_query($koneksi, "SELECT * FROM pengaduan");
                    while ($data = mysqli_fetch_array($sql)) {

                        ?>
                        <tbody>
                            <tr>
                                <td>
                                    <?php echo $data['id_pengaduan']; ?>
                                </td>
                                <td>
                                    <?php echo $data['tgl_pengaduan']; ?>
                                </td>
                                <td>
                                    <?php echo $data['nik']; ?>
                                </td>
                                <td>
                                    <?php echo $data['isi_laporan']; ?>
                                </td>
                                <td>
                                    <?php echo $data['foto']; ?>
                                </td>
                                <td>
                                    <?php echo $data['status']; ?>
                                </td>
                        </tbody>
                    <?php } ?>
                </table>
            </div>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

</body>

</html>