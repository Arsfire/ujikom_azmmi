<?php
include("css.php");
?>

<!DOCTYPE html>
<html lang="en">

<body id="page-top">
    <button type="button" class="btn btn-warning" onclick="frames['frame'].print();">
        <i class="fa fa-print"></i>
        Cetak Data
    </button>
    <iframe src="cetak_tanggapan.php" name="frame" width="100%" height="600" frameborder="0"></iframe>
</body>

</html>