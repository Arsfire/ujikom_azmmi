<?php
include("css.php");
session_start();
if (!isset($_SESSION['nama'])) {
  header('location:index.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<title>Login Masyarakat</title>

<body id="page-top">
  <div id="wrapper">

    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-keyboard"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Pengaduan Masyarakat<sup></sup></div>
      </a>

      <hr class="sidebar-divider my-0">
      <li class="nav-item">
        <a class="nav-link" href="masyarakat.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard Masyarakat</span></a>
      </li>


      <hr class="sidebar-divider">
      <div class="sidebar-heading">
        Pilihan Menu
      </div>

      <li class="nav-item">
        <a class="nav-link" href="?url=tulis_pengaduan">
          <i class="fas fa-edit"></i>
          <span>Tulis Pengaduan</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="?url=lihat_pengaduan">
          <i class="fas fa-search"></i>
          <span>Lihat Laporan</span></a>
      </li>

      <hr class="sidebar-divider d-none d-md-block">
      <li class="nav-item">
        <a class="nav-link" href="logout.php">
          <i class="fas fa-sign-out-alt"></i>
          <span>Keluar</span></a>
      </li>

      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>
    </ul>
    <div id="content-wrapper" class="d-flex flex-column">


      <div id="content">


        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
          <h1>Aplikasi Pelaporan Pengaduan Masyarakat</h1>
        </nav>
        <div class="container-fluid">

          <?php
          include 'halaman_masyarakat.php'
            ?>

        </div>

      </div>
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Uji Kompetensi AZMI 2023</span>
          </div>
        </div>
      </footer>
    </div>
  </div>

  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


</body>

</html>